<template>
    <div>
        <a-button
                type="primary"
        >test</a-button>
    </div>
</template>

<script>
    import "../style/button.scss"
    import AButton from "./index"
    export default {
        name: "ButtonTemplate",
        components:{
            AButton,
        }
    }
</script>

<style scoped>

</style>
module.exports = {
  productionSourceMap: false,
};
